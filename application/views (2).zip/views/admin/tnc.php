<div class="content-wrapper">
    
    <div class="col-lg-12">
<div class="card card-default">
										<div class="card-header card-header-border-bottom">
											<h2>Terms and Conditions</h2>
										</div>
										<div class="card-body">
											
                                            <form method="post" action="<?php echo base_url('Admin/doAddAboutus') ?>" id="aboutus">
                                              <textarea id="summernote" name="aboutus" id="aboutus"></textarea>
                                                <button type="submit" class="btn btn-primary mr-10">Submit</button>
                                            </form>
										</div>
									</div>
    
    
    
    </div>  
</div>


