<div class="content-wrapper">
    <div class="col-12">
    
        <div class="card card-default">
										<div class="card-header card-header-border-bottom">
											
                                            <h2>Add Languages</h2>
                                            
										</div>
										<div class="card-body">
											<form method="post" id="addlanguage" action="">
                                                <div class="error_msg"></div> 
                                                <div class="form-row">
													<div class="col-md-4 mb-3">
														<label for="validationServer01">Add Question</label>
														<input type="text" class="form-control" placeholder="Enter Language Name" name="name" id="name" value="">
													</div>
                                                    <div class="col-md-4 mb-3">
														<label for="validationServer01">Add Answere</label>
														<input type="text" class="form-control" placeholder="Enter Language Name" name="name" id="name" value="">
													</div>
													<div class="col-md-4 mb-3">
														<label for="validationServer02">Language Code</label>
														<input type="texts" class="form-control"  placeholder="Enter Language Code" name="code" id="code" value="">
													</div>
													
												</div>
												
												<button class="btn btn-primary" type="submit">Save</button>
											</form>
										</div>
									</div>
    </div>
    
  <div class="col-12">
								
								</div> 
</div>


