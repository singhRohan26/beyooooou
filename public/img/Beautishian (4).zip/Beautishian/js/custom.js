$(document).ready(function(){
   $('.myAccount').click(function(){       
       $('.accountDrop').slideToggle();
   })     
});

$(document).on("click", function (event) {
    var $trigger = $(".header");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $(".accountDrop").slideUp("fast");
    }
});


$(window).scroll(function () {
    if ($(window).scrollTop() >= 5) {
        $('.header').addClass('fixed_header');
    } else {
        $('.header').removeClass('fixed_header');
    }
});


$(document).ready(function(){
   $('.locationDtl ul li a').mouseenter(function(){
      var locImage = $(this).parent('li').children('img').attr('src');
    $('.locationMap img').attr('src', locImage).fadeIn();
       
   });    
});





// tab start
$(document).ready(function () {
    $('.payDtl').hide();
    $('.payDtl1').show();
    $('.clicktab').click(function () {
        var type = $(this).data('type');
        $('.payDtl').hide();
        $('.payDtl' + type).fadeIn();
        $('.clicktab').removeClass('active');
        $(this).addClass('active');
    });
});
// tab end


$(document).ready(function() {

    $('.sort').click(function(event) {
        event.stopPropagation();
        $('.filDrop_content').slideToggle();
    });

    $(document).click(function() {
        $('.filDrop_content').slideUp();
    });
});


$('.book_btn a').click(function(){
$('.choose_sec').show();
});

// modal start
$('.psd_fwd').click(function(){
$('.psd_hide').show();
$('.psd_show').hide();
});
// modal end

// $('.book_btn').hover(function(){
// var book = $(this).find('a').text('selected');
// alert(book);
// });

$(document).ready(function () {
    $(".set > a").on("click", function () {
        if ($(this).hasClass("active")) {
            $(this).removeClass("active");
            $(this).siblings(".content").slideUp(500);
            $(".set > a i").removeClass("fa-caret-down rotate").addClass("fa-caret-down");
        } else {
            $(".set > a i").removeClass("fa-caret-down rotate").addClass("fa-caret-down");
            $(this).find("i").removeClass("fa-caret-down").addClass("fa-caret-down rotate");

            $(".set > a").removeClass("active");
            $(this).addClass("active");
            $(".content").slideUp(500);
            $(this).siblings(".content").slideDown(500);
        }
    });
});
